const cassandra = require("cassandra-driver");
var genericResponse = require("../config/genericResponse.json");
const uuid = require("uuid");
const fs = require("fs");
var moment = require('moment');

var maxId;
var resultArray = {};
const client = new cassandra.Client({
  contactPoints: ["127.0.0.1"],
  keyspace: "chat",
  localDataCenter: "datacenter1"
});

client.connect(err => {
  if (err) console.log(`Error in connecting to cassandra: ${err}`);
  else console.log("Cassandra-API Connection Established.");
});

exports.client = client;


/********************************************SAVE MESSGAES**************************************** */
/**
 * @author Shefali B
 * @lastupdatedate 10 June 2020 
 * @description Saves sender messages to cassandra
 * @param {*} req 
 * @param {*} res 
 */
exports.saveMsg = (req, res) => {
  console.log("message body", req.body);
  let messageId = uuid.v1();
  let current_datetime = new Date();
  let noData = "NA";

  var query = `insert into chat.chat_messages(
					room_id,
					sender_id,
					sender_role ,
					sent_date,
					original_message,
					message_id,
					file_name,
					username ,
					source_language_code ,
					original_msg_id ,
					reference_msg_id,
					reply_or_forward,
					favourite_msg,
					updated_date ,
					created_date 
				) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);`;
  if (req.body.originalMessageId === "NA" && req.body.referenceMessageId === "NA") {
    req.body.originalMessageId = messageId;
    req.body.referenceMessageId = messageId;
  }
  var params = [
    req.body.roomId,
    req.body.senderId,
    req.body.senderRole,
    req.body.messageDate,
    req.body.originalMessage,
    messageId,
    req.body.fileName,
    req.body.userName,
    req.body.sourceLanguageCode,
    req.body.originalMessageId,
    req.body.referenceMessageId,
    req.body.replyOrForward,
    req.body.favouriteMsg,
    current_datetime,
    current_datetime
  ];

  client
    .execute(query, params, {
      prepare: true
    })
    .then(result => {
      let resBody = {
        roomId: req.body.roomId,
        senderId: req.body.senderId,
        senderRole: req.body.senderRole,
        sendDate: req.body.messageDate,
        originalMessage: req.body.originalMessage,
        messageId: messageId,
        fileName: req.body.fileName,
        userName: req.body.userName,
        sourceLanguageCode: req.body.sourceLanguageCode,
        updatedDate: current_datetime,
        createdDate: current_datetime,
        originalMessageId: req.body.originalMessageId,
        referenceMessageId: req.body.referenceMessageId,
        replyOrForward: req.body.replyOrForward,
        favouriteMsg: req.body.favouriteMsg,
        fromUserDisplayName: req.body.fromUserDisplayName,
        fromUserFirstName: req.body.fromUserFirstName,
        replyMessageDetails: req.body.replyMessageDetails
      };

      let receivedMessagesRes = saveReceivedMessage(resBody);
      if (receivedMessagesRes["status"] = "success") {
        genericResponse["status"] = "success";
        genericResponse["message"] = "Message inserted sucessfully!!";
        genericResponse["responseObject"] = resBody;
        res.send(genericResponse);
      } else {
        genericResponse["status"] = "error";
        genericResponse["message"] = receivedMessagesRes["responseObject"];
        genericResponse["responseObject"] = {};
        res.send(genericResponse);
      }
    })
    .catch(error => {
      console.log(
        "***********************Message sending error*********************\n",
        error
      );
      genericResponse["status"] = "error";
      genericResponse["message"] = error;
      genericResponse["responseObject"] = {};
      res.send(genericResponse);
    });
};

/**
 * @author Shefali B
 * @lastupdatedate 10 June 2020 
 * @description Saves received messages to cassandra
 * @param {*} req 
 * @param {*} res 
 */
async function saveReceivedMessage(resBody) {
  console.log("got received message");
  var current_datetime = new Date();

  var query = `insert into chat.received_chat_messages(
                room_id ,
                sender_id ,
                message_id ,
                original_message ,
                received_message ,
                file_name ,
                source_language_code ,
                target_language_code ,
                reference_msg_id ,
                favourite_msg ,
                reply_or_forward, 
                updated_date ,
                created_date,
                original_message_id,
                original_message_date ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);`;

  var params = [
    resBody.roomId,
    resBody.senderId,
    resBody.messageId,
    resBody.originalMessage,
    resBody.receivedMessage,
    resBody.fileName,
    resBody.sourceLanguageCode,
    resBody.targetLanguageCode,
    resBody.referenceMessageId,
    resBody.favouriteMsg,
    resBody.replyOrForward,
    current_datetime,
    current_datetime,
    resBody.originalMessageId,
    resBody.sendDate
  ];
  try {
    let result = await client.execute(query, params, {
      prepare: true
    });
    console.log("result: ", result);
    genericResponse["status"] = "success";
    genericResponse["message"] = "Sucessfully inserted";
    genericResponse["responseObject"] = result.rows;
  } catch (error) {
    console.log("error : ", error);
    genericResponse["status"] = "error";
    genericResponse["message"] = "Got error while inserting";
    genericResponse["responseObject"] = error;
  }
  return genericResponse;
}


/**
 * @author Shefali B
 * @lastupdatedate  9 july 2020
 * @description Saves receiver to cassandra
 * @param {*} req 
 * @param {*} res 
 */
exports.saveReceivedMessageReceiver = (req, res) => {
  console.log(" saveReceieverData : saving receiver info");
  var current_datetime = new Date();

  const query = `insert into chat.received_chat_messages_receiver(
						room_id ,    
						message_id ,
						received_date ,
						receiver_id ,
						username ,    
            receiver_role ,
            seen,
						updated_date ,
						created_date
					) values(?,?,?,?,?,?,?,?,?)`;

  let params = [
    req.body.roomId,
    req.body.messageId,
    req.body.messageDate,
    req.body.receiverId,
    req.body.userName,
    req.body.receiverRole,
    req.body.seen,
    current_datetime,
    current_datetime
  ];

  client
    .execute(query, params, {
      prepare: true
    })
    .then(async result => {
      console.log("result\n", result);
      let resBody = {
        room_id: req.body.roomId,
        messageId: req.body.messageId,
        receivedDate: req.body.messageDate,
        receiverId: req.body.receiverId,
        userName: req.body.userName,
        receiverRole: req.body.roomId,
        seen: req.body.seen,
        updatedDate: current_datetime,
        createdDate: current_datetime
      };
      console.log("resBody", resBody);
      genericResponse["status"] = "Success";
      genericResponse["message"] = "Receiver Data saved sucessdylly!!";
      genericResponse["responseObject"] = resBody;
      res.send(genericResponse);
    })
    .catch(error => {
      console.log("error while receiving ", error);
      genericResponse["status"] = "error";
      genericResponse["message"] = error;
      genericResponse["responseObject"] = {};
      res.send(genericResponse);
    });

}

/**
 * @author Shefali B
 * @lastupdatedate  20 may 2020
 * @description Saves receiver to cassandra
 * @param {*} req 
 * @param {*} res 
 */
exports.updateSeenStatus = (req, res) => {

  var params = [req.body.seen, req.body.roomId, req.body.username, req.body.messageId, req.body.receivedDate];

  var query = `UPDATE chat.received_chat_messages_receiver SET seen = ?   WHERE room_id = ? AND username = ? AND message_id= ? AND received_date= ? `;

  client
    .execute(query, params, {
      prepare: true
    })
    .then(result => {
      genericResponse["status"] = "Success";
      genericResponse["message"] = "updated seen status of msg.";
      genericResponse["responseObject"] = result;
      res.send(genericResponse);
    })
    .catch(error => {
      genericResponse["status"] = "error";
      genericResponse["message"] = error;
      genericResponse["responseObject"] = {};
      res.send(genericResponse);
    });

}

