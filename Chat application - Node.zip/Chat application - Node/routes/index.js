var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res) {
  res.send('<h3>Hello Wolrd!!</h3>');
});

module.exports = router;
