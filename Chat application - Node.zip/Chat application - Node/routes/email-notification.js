const nodemailer = require('nodemailer');
const fs = require('fs');
const handlebars = require('handlebars');
const genericResponse = require('../config/genericResponse.json');
const config = require('../config/config.json');


const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 465,
  secure: true,
  auth: {
    type: 'Oauth2',
    user: config.googleOauth2.GMAIL_ADDRESS,
    clientId: config.googleOauth2.GMAIL_OAUTH_CLIENT_ID,
    clientSecret: config.googleOauth2.GMAIL_OAUTH_CLIENT_SECRET,
    refreshToken: config.googleOauth2.GMAIL_OAUTH_REFRESH_TOKEN,
    accessToken: config.googleOauth2.GMAIL_OAUTH_ACCESS_TOKEN,
    expires: Number.parseInt(config.googleOauth2.GMAIL_OAUTH_TOKEN_EXPIRE, 10)
  }
});


const readHTMLFile = (path) => {
  return new Promise((resolve, reject) => {
    fs.readFile(path, {
      encoding: 'utf-8'
    }, (err, html) => {
      if (err) {
        reject(err);
      } else {
        resolve(html);
      }
    });
  });
}

/**
 * @author Shefali B
 * @lastupdatedate 10 June 2020 
 * @description Send email notification
 * @param {*} req 
 * @param {*} res 
 */
exports.sendEmailNotification = async (req, res) => {

  var sender = req.body.invitationBy;
  var receiverList = req.body.invitationTo;

  let invitationToMailStr = '';
  for (inviteTo of receiverList) {
    invitationToMailStr = invitationToMailStr + inviteTo.userMail + ',';
  }

  var html;
  try {
    html = await readHTMLFile('templates/meetingScheduledNotify.html');
  } catch (error) {
    console.error(`error in reading HTML file: ${error}`);
  }
  const template = handlebars.compile(html);
  const replacements = {
    meetTopic: req.body.meetTopic,
    scheduledDate: req.body.scheduledDate,
    meetStartTime: req.body.meetStartTime,
    duration: req.body.duration,
    meetPassword: req.body.meetPassword,
    meetingId: req.body.meetingId,
    invitationBy: sender,
  };
  const htmlToSend = template(replacements);
  const message = {
    from: `Koncalls <${config.googleOauth2.GMAIL_ADDRESS}>`,
    to: invitationToMailStr,
    subject: 'Meeting has been scheduled on Koncalls',
    html: htmlToSend,
  }
  transporter.sendMail(message, (error, info) => {
    if (error) {
      genericResponse['status'] = 'Error';
      genericResponse['message'] = "Email notification failed!!";
      genericResponse['responseObject'] = error;
      res.send(genericResponse);
    } else {
      console.log('Email sent: ' + JSON.stringify(info));
      genericResponse['status'] = 'Success';
      genericResponse['message'] = "Email sent sucessfully!!";
      genericResponse['responseObject'] = info;
      res.send(genericResponse);
    }
  });
}


/**
 * @author Shefali B
 * @lastupdatedate 10 June 2020 
 * @description Send Invitaion to join a group
 * @param {*} req 
 * @param {*} res 
 */
exports.sendJoinGroupInvitations = async (req, res) => {

  var html;
  try {
    html = await readHTMLFile('templates/groupInvities.html');
  } catch (error) {
    console.error(`error in reading HTML file: ${error}`);
  }
  let toEmails = req.body.toEmails;
  let i = 0;
  toEmails.forEach(email => {
    const template = handlebars.compile(html);
    const replacements = {
      toEmails: email,
      fromEmail: req.body.fromEmail
    };
    const htmlToSend = template(replacements);
    const message = {
      from: `Sample Chat <${config.googleOauth2.GMAIL_ADDRESS}>`,
      to: email,
      subject: 'No reply',
      html: htmlToSend,
    }
    transporter.sendMail(message, (error, info) => {
      if (error) {
        console.log(`error: ${JSON.stringify(error)}`);
      } else {
        i++;
        console.log("");
        if (i == toEmails.length) {
          res.status(200).send(`Email sent: ${info}`);
        }
      }
    });
  });
}