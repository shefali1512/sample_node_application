const { Parser } = require('json2csv');

let roomList = [];

const searchRoom = (roomId) => {
  if (roomList.length === 0) {
    console.log('roomList is empty!');
    return false;
  }
  else {
    for (let index = 0; index < roomList.length; index++) {
      if (roomId == roomList[index]) {
        return true;
      }
    }
    return false;
  }
}


const roomData = (elementList, flag) => {
  if (flag == 'R') {
    let dataStr = {
      receiver: elementList[5],
      message: elementList[2],
      time: elementList[4]
    }
    return dataStr;
  }
  if (flag == 'S') {
    let dataStr = {
      sender: elementList[5],
      message: elementList[2],
      time: elementList[4]
    }
    return dataStr;
  }
}

//Adding all rooms data
const formatData = (str, flag) => {
  let returnFileObject = {};
  let rows = str.split('~');

  for (let index = 0; index < rows.length; index++) {
    let rowElement = rows[index];
    let elementList = rowElement.split('||');
    let dataList = [];
    let found = searchRoom(elementList[0]);
    if (found) {
      let dataStr = roomData(elementList, flag);
      returnFileObject[elementList[0]].push(dataStr);
    }
    else {
      roomList.push(elementList[0]);
      let dataStr = roomData(elementList, flag);
      dataList.push(dataStr);
      returnFileObject[elementList[0]] = dataList;
    }
    dataList = [];
  }
  roomList = [];
  return returnFileObject;
}

//Adding specific room data
const formatRoomData = (str, flag, roomId) => {
  //str = str.slice(0, -1);
  let returnFileObject = {};
  let rows = str.split('~');

  let foundFlag = 0;
  for (let index = 0; index < rows.length; index++) {
    let dataList = [];
    let rowElement = rows[index];
    let roomElement = rowElement.split('||', 1);
    if (roomElement == roomId) {
      foundFlag += 1;
      let elementList = rowElement.split('||');
      if (foundFlag == 1) {
        let dataStr = roomData(elementList, flag);
        dataList.push(dataStr);
        returnFileObject = dataList;
      }
      else if (foundFlag > 1) {
        //updating room data
        let dataStr = roomData(elementList, flag);
        returnFileObject.push(dataStr);
      }
    }
    dataList = [];
  }
  return returnFileObject;
}

const createCSV = (csvObject) => {
  let returnObject = {
    senderCSV: '',
    receiverCSV: ''
  };
  if (csvObject.hasOwnProperty('senderCSV')) {
    const csvObjectList = csvObject['senderCSV'];
    const fields = ['date', 'dfsTimestamp', 'dfsTimestampUTC', 'senderName', 'message', 'time'];
    const json2csvParser = new Parser({ fields });
    const csv = json2csvParser.parse(csvObjectList);
    returnObject['senderCSV'] = csv;
  }
  if (csvObject.hasOwnProperty('receiverCSV')) {
    const csvObjectList = csvObject['receiverCSV'];
    const fields = ['date', 'dfsTimestamp', 'dfsTimestampUTC', 'receiverName', 'message', 'time'];
    const json2csvParser = new Parser({ fields });
    const csv = json2csvParser.parse(csvObjectList);
    returnObject['receiverCSV'] = csv;
  }
  return returnObject;
}

const prepareCSVData = (objectNew2) => {
  let csvObjectListSender = [];
  let csvObjectListReceiver = [];
  for (const key in objectNew2) {
    if (objectNew2.hasOwnProperty(key)) {
      const objectList = objectNew2[key];
      for (let index = 0; index < objectList.length; index++) {
        const obj = objectList[index];
        if (obj.hasOwnProperty('senderFile') && obj['senderFile'] !== undefined) {
          let senderFileList = obj['senderFile'];
          for (let i = 0; i < senderFileList.length; i++) {
            let csvObject = {
              date: '',
              dfsTimestamp: '',
              dfsTimestampUTC: '',
              senderName: '',
              message: '',
              time: ''
            };
            const senderFileObj = senderFileList[i];
            csvObject['date'] = key;
            csvObject['dfsTimestamp'] = obj['timestamp'];
            csvObject['dfsTimestampUTC'] = obj['timestampUTC'];
            csvObject['senderName'] = senderFileObj['sender'];
            csvObject['message'] = senderFileObj['message'];
            csvObject['time'] = senderFileObj['time'];
            csvObjectListSender.push(csvObject);
          }
        }
        if (obj.hasOwnProperty('receiverFile') && obj['receiverFile'] !== undefined) {
          let receiverFileList = obj['receiverFile'];
          for (let i = 0; i < receiverFileList.length; i++) {
            let csvObject = {
              date: '',
              dfsTimestamp: '',
              dfsTimestampUTC: '',
              receiverName: '',
              message: '',
              time: ''
            };
            const receiverFileObj = receiverFileList[i];
            csvObject['date'] = key;
            csvObject['dfsTimestamp'] = obj['timestamp'];
            csvObject['dfsTimestampUTC'] = obj['timestampUTC'];
            csvObject['receiverName'] = receiverFileObj['receiver'];
            csvObject['message'] = receiverFileObj['message'];
            csvObject['time'] = receiverFileObj['time'];
            csvObjectListReceiver.push(csvObject);
          }
        }
      }
    }
  }

  return {
    senderCSV: csvObjectListSender,
    receiverCSV: csvObjectListReceiver
  }
}


module.exports = { formatRoomData, prepareCSVData, createCSV };



