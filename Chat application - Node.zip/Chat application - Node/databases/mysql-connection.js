// const { development } = require("../config/mysql-config.json");
// const Sequelize = require("sequelize");
// const sequelize = new Sequelize(
//   development.database,
//   development.username,
//   development.password,
//   {
//     host: development.host,
//     dialect: development.dialect
//   }
// );

// let testConnection = async () => {
//   try {
//     await sequelize.authenticate();
//     console.log(
//       "MySQL Connection via sequelize has been established successfully."
//     );
//   } catch (error) {
//     console.error(
//       "Unable to establish connection to MySQL via sequelize:",
//       error
//     );
//   }
// };

// let syncDB = async () => {
//   try {
//     await sequelize.sync();
//     console.log("database synced.");
//   } catch (error) {
//     console.error("unable to sync database", error);
//   }
// };

// testConnection();
// syncDB();

// module.exports = sequelize;
