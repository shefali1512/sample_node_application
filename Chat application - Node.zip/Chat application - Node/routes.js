var express = require("express");
var router = express.Router();
const chat_api = require("./routes/cassandra-api");
const email_notification = require("./routes/email-notification");

const {
  Stream
} = require('./scheduler/meeting-scheduler');


//------------------------cassandra APIs--------------------------------

/************* SAVE MESSAGES **************/

router.post("/received-msg-receiver", chat_api.saveReceivedMessageReceiver);
router.post("/save-msg", chat_api.saveMsg);
router.post("/forward-message", chat_api.saveForwardedMessage);

/************* GET MESSAGES **************/

router.get("/chat-msg/:roomId", chat_api.getChatMessages);
router.get("/chat-received-msg/:roomId", chat_api.getreceivedChatMessages);

router.post("/get-all-messages", chat_api.getAllMessages);
router.post("/get-received-msg", chat_api.getReceivedMessage);
router.post("/messages", chat_api.getMessagesTest);

router.post("/get-msg-bymsgid", chat_api.getMessageByMessageId);
router.post("/is-room-available", chat_api.getRoomByName);

router.get("/chat-received-receiver-msg/:roomId", chat_api.getreceivedChatMessagesreceiver);
router.post("/schedule-meet-mail-notif", email_notification.sendEmailNotification);

router.get("/get-history-msg/:userName/:roomId", chat_api.getHistoryMessages);

router.put("/seen-status", chat_api.updateSeenStatus);


router.delete("/clear-chat/:roomId/:username", chat_api.deleteChatHistory);

module.exports = router;