let app = require("express")();
let http = require("http").Server(app);
const {
  meetSchedulerInit
} = require("./scheduler/meeting-scheduler");
const routes = require("./routes");
const cors = require("cors");
const bodyParser = require("body-parser");

app.use(cors(), (req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE");
  next();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));

// require("./databases/mysql-connection");
// require("./models/model-index");

app.use("/", routes);
app.use("/", require("./routes/index"));
// meetSchedulerInit();

let PORT = 3040 || process.env.PORT;

http.listen(PORT, () => {
  console.log(`Server is started at port ${PORT}`);
});